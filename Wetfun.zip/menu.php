<!DOCTYPE html>
<html lang="es">
<?php
    include("includes/head.php");
?>

<body>
    <?php
        include("includes/header.php");
        include("modules/menu.php");
        include("includes/redes.php");
        include("includes/footer.php");
        include("includes/scripts.php");
    ?>
</body>

</html>