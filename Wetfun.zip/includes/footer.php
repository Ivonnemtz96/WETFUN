<!-- FOOTER SECTION -->
<div class="footer" data-background="images/dummy-img-1920x900-3.jpg">
   

    <div class="fcopy">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-12">
                    <p class="ftex">Copyright 2023 &copy; <span class="color-primary">Wild Wet Fun</span>.
                        Diseñado por <a href="https://www.bananagroup.mx/" target="_blank"><strong class="text-white">Banana Group Marketing</strong></a></p>
                </div>
            </div>
        </div>
    </div>

</div>